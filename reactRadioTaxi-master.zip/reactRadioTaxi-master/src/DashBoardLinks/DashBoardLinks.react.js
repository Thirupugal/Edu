import React from 'react';



const DashBoardLinks = () => {

    return (
        <div >

        <ul>
            <li><a href="">Home</a></li>
            <li><a href="">Payment History</a></li>
            <li><a href="">Request Loan</a></li>
            <li><a href="">Contact</a></li>
        </ul>
        
        </div>
    );

}

export default DashBoardLinks;